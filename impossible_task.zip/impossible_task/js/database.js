let users = JSON.parse(window.localStorage.getItem("users")) || [
    {
        userId: 1,
        userName: "Ali",
        contact: "998975661099"
    },
    {
        userId: 2,
        userName: "Vali",
        contact: "998975667899"
    },
    {
        userId: 3,
        userName: "Alisher",
        contact: "99897581099"
    },
]


let foods = JSON.parse(window.localStorage.getItem("foods")) || [
    {foodId : 1, foodName : "Combo", foodImg: "./img/combo.jpeg"},
    {foodId : 2, foosName: "Fanta",  foodImg: "./img/fanta.jpeg"},
    {foodId : 3, foodName: "Spinner", foodImg: "./img/spinner.jpeg"},
]

let orders = JSON.parse(window.localStorage.getItem("orders"))[
    {
        orderId: 1,
        userId : 1,
        foodId : 2,
        count: 2
    }, 
    {
        orderId : 1,
        userId : 1,
        foodId : 3,
        count : 2
    }
]